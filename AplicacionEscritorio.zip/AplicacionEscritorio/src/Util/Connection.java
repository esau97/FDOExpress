package Util;

public class Connection {
    Connection connection;
    public Connection(){

    }
}
