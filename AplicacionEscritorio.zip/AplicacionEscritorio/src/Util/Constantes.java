package Util;

import Entity.User;

public class Constantes {
    public static User DATOS_USUARIO = new User();
    public static int PUERTO = 4444;
}
