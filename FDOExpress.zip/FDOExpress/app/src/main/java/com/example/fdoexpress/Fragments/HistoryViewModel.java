package com.example.fdoexpress.Fragments;

import androidx.lifecycle.ViewModel;

public class HistoryViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
