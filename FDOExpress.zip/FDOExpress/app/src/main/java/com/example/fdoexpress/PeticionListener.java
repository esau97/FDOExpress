package com.example.fdoexpress;

public interface PeticionListener {
    void callback(String accion) ;
}
