package com.example.fdoexpress.Utils;

public class Constantes {
    public static String STRING_PREFERENCES ="data.login";
    public static String PREFERENCE_LOGIN_STATE="login.state";
    public static String USER_NAME ="user.name";
    public static String USER_PASSWORD ="user.password";
}
